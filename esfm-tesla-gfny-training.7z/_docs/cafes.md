---
layout: default
title: Cafés / Kitchenettes / Break Areas
parent: Frontline SOPs
nav_order: 2
slug: cafes
---

{% include lang_switch.html slug="cafes" %}

# Cafés / Kitchenettes / Break Areas

Content TBD.
