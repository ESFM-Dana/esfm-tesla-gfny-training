---
layout: default
title: End of Shift — Managers
parent: End of Shift
nav_order: 2
slug: eos-mgrs
---

{% include lang_switch.html slug="eos-mgrs" %}

# End of Shift — Managers

Content TBD.
