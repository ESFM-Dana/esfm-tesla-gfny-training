---
layout: default
title: Download Center — DOCX Originals
nav_order: 17
slug: downloads-docx
---

{% include lang_switch.html slug="downloads-docx" %}

# Download Center — DOCX Originals

- [all serviceable areas for compass  (1).docx]({{ '/assets/files/en/all serviceable areas for compass  (1).docx' | relative_url }})
- [bathroom route card 1st shift .docx]({{ '/assets/files/en/bathroom route card 1st shift .docx' | relative_url }})
- [Best_Practices_Guide 2.docx]({{ '/assets/files/en/Best_Practices_Guide 2.docx' | relative_url }})
- [Daily_End_of_Shift_Procedures.docx]({{ '/assets/files/en/Daily_End_of_Shift_Procedures.docx' | relative_url }})
- [Daily_End_of_Shift_Procedures_2.docx]({{ '/assets/files/en/Daily_End_of_Shift_Procedures_2.docx' | relative_url }})
- [Document.docx]({{ '/assets/files/en/Document.docx' | relative_url }})
- [ESFM_Tesla_GFNY_Leadership_Playbook.docx]({{ '/assets/files/en/ESFM_Tesla_GFNY_Leadership_Playbook.docx' | relative_url }})
- [GFNY Janitorial Services WO compass .docx]({{ '/assets/files/en/GFNY Janitorial Services WO compass .docx' | relative_url }})
- [GFNY Trash Collection Training Manual.docx]({{ '/assets/files/en/GFNY Trash Collection Training Manual.docx' | relative_url }})
- [GFNY_Cafés_Kitchenettes_Zone_Training_Manual.docx]({{ '/assets/files/en/GFNY_Cafés_Kitchenettes_Zone_Training_Manual.docx' | relative_url }})
- [GFNY_Exteriors_Lobbies_Zone_Training_Manual.docx]({{ '/assets/files/en/GFNY_Exteriors_Lobbies_Zone_Training_Manual.docx' | relative_url }})
- [GFNY_Floor Tech_Training.docx]({{ '/assets/files/en/GFNY_Floor Tech_Training.docx' | relative_url }})
- [GFNY_Janitor_Training.docx]({{ '/assets/files/en/GFNY_Janitor_Training.docx' | relative_url }})
- [GFNY_Lead_Training.docx]({{ '/assets/files/en/GFNY_Lead_Training.docx' | relative_url }})
- [GFNY_Manager_Training.docx]({{ '/assets/files/en/GFNY_Manager_Training.docx' | relative_url }})
- [GFNY_Offices_Training Rooms_Zone_Training_Manual.docx]({{ '/assets/files/en/GFNY_Offices_Training Rooms_Zone_Training_Manual.docx' | relative_url }})
- [GFNY_Project Worker_Training.docx]({{ '/assets/files/en/GFNY_Project Worker_Training.docx' | relative_url }})
- [GFNY_QR_Process_Quick_Guide_Final.docx]({{ '/assets/files/en/GFNY_QR_Process_Quick_Guide_Final.docx' | relative_url }})
- [GFNY_Restrooms_Zone_Training_Manual.docx]({{ '/assets/files/en/GFNY_Restrooms_Zone_Training_Manual.docx' | relative_url }})
- [GFNY_Warehouses_Production_Zone_Training_Manual.docx]({{ '/assets/files/en/GFNY_Warehouses_Production_Zone_Training_Manual.docx' | relative_url }})
- [route card - compass cafes .docx]({{ '/assets/files/en/route card - compass cafes .docx' | relative_url }})
- [route card - meditation rooms - ,compass .docx]({{ '/assets/files/en/route card - meditation rooms - ,compass .docx' | relative_url }})
- [route card - mothers rooms - compass .docx]({{ '/assets/files/en/route card - mothers rooms - compass .docx' | relative_url }})
- [route card - office space - esfm .docx]({{ '/assets/files/en/route card - office space - esfm .docx' | relative_url }})
- [route card - trash - compass .docx]({{ '/assets/files/en/route card - trash - compass .docx' | relative_url }})
- [route cards - lobby and sanitation - compass .docx]({{ '/assets/files/en/route cards - lobby and sanitation - compass .docx' | relative_url }})
