---
layout: default
title: Instrucciones de QR — Solo al Salir
parent: Operaciones y Complementos
nav_order: 4
slug: qr
---

{% include lang_switch.html slug="qr" %}

# Instrucciones de QR — Solo al Salir

Contenido pendiente.
