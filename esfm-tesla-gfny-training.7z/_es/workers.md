---
layout: default
title: Trabajadores de Proyectos — Capacitación
parent: Roles y Capacitación
nav_order: 6
slug: workers
---

{% include lang_switch.html slug="workers" %}

# Trabajadores de Proyectos — Capacitación

Contenido pendiente.
