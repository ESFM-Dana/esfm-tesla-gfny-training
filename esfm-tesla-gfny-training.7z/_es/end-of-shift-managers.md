---
layout: default
title: Fin de Turno — Gerentes
parent: Fin de Turno
nav_order: 2
---

# Fin de Turno — Gerentes

_Traducción pendiente de **End of Shift — Managers**. Consulte la versión en inglés._

> [Ver la página en inglés]({{ "/end-of-shift-managers" | relative_url }})
