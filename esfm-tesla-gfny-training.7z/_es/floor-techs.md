---
layout: default
title: Técnicos de Piso — Estándares de Piso
parent: Roles y Capacitación
nav_order: 3
---

# Técnicos de Piso — Estándares de Piso

_Traducción pendiente de **Floor Techs — Floor Care Standards**. Consulte la versión en inglés._

> [Ver la página en inglés]({{ "/floor-techs" | relative_url }})
