---
layout: default
title: Cuarto de Limpieza
parent: Operaciones y Complementos
nav_order: 2
---

# Cuarto de Limpieza

_Traducción pendiente de **Janitor’s Closet**. Consulte la versión en inglés._

> [Ver la página en inglés]({{ "/janitor-closets" | relative_url }})
