---
layout: default
title: Vestíbulos / Entradas / Seguridad
parent: SOP de Operación — Frontline
nav_order: 3
slug: lobbies
---

{% include lang_switch.html slug="lobbies" %}

# Vestíbulos / Entradas / Seguridad

Contenido pendiente.
