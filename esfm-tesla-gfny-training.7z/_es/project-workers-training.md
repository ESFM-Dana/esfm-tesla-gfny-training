---
layout: default
title: Trabajadores de Proyectos — Capacitación
parent: Roles y Capacitación
nav_order: 6
---

# Trabajadores de Proyectos — Capacitación

_Traducción pendiente de **Project Workers — Training**. Consulte la versión en inglés._

> [Ver la página en inglés]({{ "/project-workers-training" | relative_url }})
