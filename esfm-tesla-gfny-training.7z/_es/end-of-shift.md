---
layout: default
title: Fin de Turno
parent: Español
nav_order: 5
has_children: true
permalink: /es/end-of-shift/
slug: end-of-shift
---

{% include lang_switch.html slug="end-of-shift" %}

# Fin de Turno
