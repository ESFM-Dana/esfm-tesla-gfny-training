---
layout: default
title: Recolección de Basura (Interior y Exterior)
parent: Operaciones y Complementos
nav_order: 3
slug: trash
---

{% include lang_switch.html slug="trash" %}

# Recolección de Basura (Interior y Exterior)

Contenido pendiente.
