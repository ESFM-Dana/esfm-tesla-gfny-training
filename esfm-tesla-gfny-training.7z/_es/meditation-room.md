---
layout: default
title: Salas de Meditación
parent: SOP de Operación — Frontline
nav_order: 6
---

# Salas de Meditación

_Traducción pendiente de **Meditation Rooms**. Consulte la versión en inglés._

> [Ver la página en inglés]({{ "/meditation-room" | relative_url }})
