---
layout: default
title: غرف التأمل
parent: إجراءات التشغيل — الصف الأول
nav_order: 6
slug: meditation
---

{% include lang_switch.html slug="meditation" %}

<div dir="rtl" lang="ar" markdown="1">
# غرف التأمل

المحتوى قيد الإعداد.
</div>
