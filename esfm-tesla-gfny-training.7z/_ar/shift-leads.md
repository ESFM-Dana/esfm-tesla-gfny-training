---
layout: default
title: قادة الوردية — دليل EVS
parent: الأدوار والتدريب
nav_order: 2
---

<div dir="rtl" lang="ar">
# قادة الوردية — دليل EVS

الترجمة قيد الإعداد لصفحة **Shift Leads — EVS Playbook**. يُرجى مراجعة النسخة الإنجليزية.

> [الاطلاع على الصفحة الإنجليزية]({{ "/shift-leads" | relative_url }})
</div>
