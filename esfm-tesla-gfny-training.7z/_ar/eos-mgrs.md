---
layout: default
title: نهاية الوردية — المديرون
parent: نهاية الوردية
nav_order: 2
slug: eos-mgrs
---

{% include lang_switch.html slug="eos-mgrs" %}

<div dir="rtl" lang="ar" markdown="1">
# نهاية الوردية — المديرون

المحتوى قيد الإعداد.
</div>
