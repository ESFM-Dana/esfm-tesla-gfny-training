---
layout: default
title: EVS المصنع — النطاق والمعايير
parent: الأدوار والتدريب
nav_order: 4
---

<div dir="rtl" lang="ar">
# EVS المصنع — النطاق والمعايير

الترجمة قيد الإعداد لصفحة **Factory EVS — Scope & Standards**. يُرجى مراجعة النسخة الإنجليزية.

> [الاطلاع على الصفحة الإنجليزية]({{ "/factory-evs" | relative_url }})
</div>
