---
layout: default
title: جمع النفايات (داخلي وخارجي)
parent: العمليات والإضافات
nav_order: 3
---

<div dir="rtl" lang="ar">
# جمع النفايات (داخلي وخارجي)

الترجمة قيد الإعداد لصفحة **Trash Collection (Interior & Exterior)**. يُرجى مراجعة النسخة الإنجليزية.

> [الاطلاع على الصفحة الإنجليزية]({{ "/trash-collection" | relative_url }})
</div>
