---
layout: default
title: المقاهي / المطابخ الصغيرة / مناطق الاستراحة
parent: إجراءات التشغيل — الصف الأول
nav_order: 2
slug: cafes
---

{% include lang_switch.html slug="cafes" %}

<div dir="rtl" lang="ar" markdown="1">
# المقاهي / المطابخ الصغيرة / مناطق الاستراحة

المحتوى قيد الإعداد.
</div>
