---
layout: default
title: عمّال المشاريع — التدريب
parent: الأدوار والتدريب
nav_order: 6
slug: workers
---

{% include lang_switch.html slug="workers" %}

<div dir="rtl" lang="ar" markdown="1">
# عمّال المشاريع — التدريب

المحتوى قيد الإعداد.
</div>
