---
layout: default
title: تعليمات QR — الالتزام عند الخروج فقط
parent: العمليات والإضافات
nav_order: 4
---

<div dir="rtl" lang="ar">
# تعليمات QR — الالتزام عند الخروج فقط

الترجمة قيد الإعداد لصفحة **QR Instructions — Exit-Only Compliance**. يُرجى مراجعة النسخة الإنجليزية.

> [الاطلاع على الصفحة الإنجليزية]({{ "/qr-instructions" | relative_url }})
</div>
