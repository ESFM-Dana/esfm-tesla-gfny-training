---
layout: default
title: قادة الوردية — دليل EVS
parent: الأدوار والتدريب
nav_order: 2
slug: leads
---

{% include lang_switch.html slug="leads" %}

<div dir="rtl" lang="ar" markdown="1">
# قادة الوردية — دليل EVS

المحتوى قيد الإعداد.
</div>
