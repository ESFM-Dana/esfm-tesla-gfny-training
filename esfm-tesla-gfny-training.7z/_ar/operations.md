---
layout: default
title: العمليات والإضافات
parent: العربية
nav_order: 3
has_children: true
permalink: /ar/operations/
slug: operations
---

{% include lang_switch.html slug="operations" %}

<div dir="rtl" lang="ar" markdown="1">
# العمليات والإضافات
</div>
