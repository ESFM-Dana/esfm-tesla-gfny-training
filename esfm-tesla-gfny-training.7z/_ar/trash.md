---
layout: default
title: جمع النفايات (داخلي وخارجي)
parent: العمليات والإضافات
nav_order: 3
slug: trash
---

{% include lang_switch.html slug="trash" %}

<div dir="rtl" lang="ar" markdown="1">
# جمع النفايات (داخلي وخارجي)

المحتوى قيد الإعداد.
</div>
