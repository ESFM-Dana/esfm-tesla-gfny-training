---
layout: default
title: Hallways / Corridors
parent: Frontline SOPs
nav_order: 4
slug: hallways
---

{% include lang_switch.html slug="hallways" %}

# Hallways / Corridors

Content TBD.
