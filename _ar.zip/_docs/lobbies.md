---
layout: default
title: Lobbies / Entrances / Security
parent: Frontline SOPs
nav_order: 3
slug: lobbies
---

{% include lang_switch.html slug="lobbies" %}

# Lobbies / Entrances / Security

Content TBD.
