---
layout: default
title: نهاية الوردية — المديرون
parent: نهاية الوردية
nav_order: 2
---

<div dir="rtl" lang="ar">
# نهاية الوردية — المديرون

الترجمة قيد الإعداد لصفحة **End of Shift — Managers**. يُرجى مراجعة النسخة الإنجليزية.

> [الاطلاع على الصفحة الإنجليزية]({{ "/end-of-shift-managers" | relative_url }})
</div>
