---
layout: default
title: المكاتب / الإداري / قاعات التدريب
parent: إجراءات التشغيل — الصف الأول
nav_order: 5
slug: offices
---

{% include lang_switch.html slug="offices" %}

<div dir="rtl" lang="ar" markdown="1">
# المكاتب / الإداري / قاعات التدريب

المحتوى قيد الإعداد.
</div>
