---
layout: default
title: فنّيو الأرضيات — معايير العناية بالأرضيات
parent: الأدوار والتدريب
nav_order: 3
---

<div dir="rtl" lang="ar">
# فنّيو الأرضيات — معايير العناية بالأرضيات

الترجمة قيد الإعداد لصفحة **Floor Techs — Floor Care Standards**. يُرجى مراجعة النسخة الإنجليزية.

> [الاطلاع على الصفحة الإنجليزية]({{ "/floor-techs" | relative_url }})
</div>
