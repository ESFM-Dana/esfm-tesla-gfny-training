---
layout: default
title: غرفة أدوات النظافة
parent: العمليات والإضافات
nav_order: 2
slug: closet
---

{% include lang_switch.html slug="closet" %}

<div dir="rtl" lang="ar" markdown="1">
# غرفة أدوات النظافة

المحتوى قيد الإعداد.
</div>
