---
layout: default
title: المديرون — دليل EVS
parent: الأدوار والتدريب
nav_order: 1
slug: managers
---

{% include lang_switch.html slug="managers" %}

<div dir="rtl" lang="ar" markdown="1">
# المديرون — دليل EVS

المحتوى قيد الإعداد.
</div>
