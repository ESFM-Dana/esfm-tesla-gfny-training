---
layout: default
title: غرفة أدوات النظافة
parent: العمليات والإضافات
nav_order: 2
---

<div dir="rtl" lang="ar">
# غرفة أدوات النظافة

الترجمة قيد الإعداد لصفحة **Janitor’s Closet**. يُرجى مراجعة النسخة الإنجليزية.

> [الاطلاع على الصفحة الإنجليزية]({{ "/janitor-closets" | relative_url }})
</div>
