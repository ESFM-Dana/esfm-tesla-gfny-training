---
layout: default
title: تعليمات QR — الالتزام عند الخروج فقط
parent: العمليات والإضافات
nav_order: 4
slug: qr
---

{% include lang_switch.html slug="qr" %}

<div dir="rtl" lang="ar" markdown="1">
# تعليمات QR — الالتزام عند الخروج فقط

المحتوى قيد الإعداد.
</div>
