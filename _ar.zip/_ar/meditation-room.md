---
layout: default
title: غرف التأمل
parent: إجراءات التشغيل — الصف الأول
nav_order: 6
---

<div dir="rtl" lang="ar">
# غرف التأمل

الترجمة قيد الإعداد لصفحة **Meditation Rooms**. يُرجى مراجعة النسخة الإنجليزية.

> [الاطلاع على الصفحة الإنجليزية]({{ "/meditation-room" | relative_url }})
</div>
