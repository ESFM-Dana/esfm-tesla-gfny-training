---
layout: default
title: الإخلاء الطارئ (EVS)
parent: العمليات والإضافات
nav_order: 1
slug: evac
---

{% include lang_switch.html slug="evac" %}

<div dir="rtl" lang="ar" markdown="1">
# الإخلاء الطارئ (EVS)

المحتوى قيد الإعداد.
</div>
