---
layout: default
title: الإخلاء الطارئ (EVS)
parent: العمليات والإضافات
nav_order: 1
---

<div dir="rtl" lang="ar">
# الإخلاء الطارئ (EVS)

الترجمة قيد الإعداد لصفحة **Emergency Evacuation (EVS)**. يُرجى مراجعة النسخة الإنجليزية.

> [الاطلاع على الصفحة الإنجليزية]({{ "/emergency-evacuation" | relative_url }})
</div>
