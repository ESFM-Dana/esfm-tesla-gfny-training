---
layout: default
title: كيفية المساهمة / التحديث

nav_order: 7
slug: about
---

{% include lang_switch.html slug="about" %}

<div dir="rtl" lang="ar" markdown="1">
# كيفية المساهمة / التحديث

المحتوى قيد الإعداد.
</div>
