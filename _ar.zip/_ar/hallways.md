---
layout: default
title: الممرات / الممرات الرئيسية
parent: إجراءات التشغيل — الصف الأول
nav_order: 4
slug: hallways
---

{% include lang_switch.html slug="hallways" %}

<div dir="rtl" lang="ar" markdown="1">
# الممرات / الممرات الرئيسية

المحتوى قيد الإعداد.
</div>
