---
layout: default
title: أعمال المشاريع — التخطيط وضمان الجودة
parent: الأدوار والتدريب
nav_order: 5
slug: projects
---

{% include lang_switch.html slug="projects" %}

<div dir="rtl" lang="ar" markdown="1">
# أعمال المشاريع — التخطيط وضمان الجودة

المحتوى قيد الإعداد.
</div>
