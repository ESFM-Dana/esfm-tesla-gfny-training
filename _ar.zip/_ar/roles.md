---
layout: default
title: الأدوار والتدريب
parent: العربية
nav_order: 4
has_children: true
permalink: /ar/roles/
slug: roles
---

{% include lang_switch.html slug="roles" %}

<div dir="rtl" lang="ar" markdown="1">
# الأدوار والتدريب
</div>
