---
layout: default
title: EVS المصنع — النطاق والمعايير
parent: الأدوار والتدريب
nav_order: 4
slug: factory
---

{% include lang_switch.html slug="factory" %}

<div dir="rtl" lang="ar" markdown="1">
# EVS المصنع — النطاق والمعايير

المحتوى قيد الإعداد.
</div>
