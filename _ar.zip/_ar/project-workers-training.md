---
layout: default
title: عمّال المشاريع — التدريب
parent: الأدوار والتدريب
nav_order: 6
---

<div dir="rtl" lang="ar">
# عمّال المشاريع — التدريب

الترجمة قيد الإعداد لصفحة **Project Workers — Training**. يُرجى مراجعة النسخة الإنجليزية.

> [الاطلاع على الصفحة الإنجليزية]({{ "/project-workers-training" | relative_url }})
</div>
