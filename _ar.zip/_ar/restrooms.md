---
layout: default
title: دورات المياه / الاستحمام
parent: إجراءات التشغيل — الصف الأول
nav_order: 1
slug: restrooms
---

{% include lang_switch.html slug="restrooms" %}

<div dir="rtl" lang="ar" markdown="1">
# دورات المياه / الاستحمام

المحتوى قيد الإعداد.
</div>
