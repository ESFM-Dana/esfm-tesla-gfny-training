---
layout: default
title: فنّيو الأرضيات — معايير العناية بالأرضيات
parent: الأدوار والتدريب
nav_order: 3
slug: floortechs
---

{% include lang_switch.html slug="floortechs" %}

<div dir="rtl" lang="ar" markdown="1">
# فنّيو الأرضيات — معايير العناية بالأرضيات

المحتوى قيد الإعداد.
</div>
