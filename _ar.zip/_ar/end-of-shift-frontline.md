---
layout: default
title: نهاية الوردية — خط المواجهة
parent: نهاية الوردية
nav_order: 1
---

<div dir="rtl" lang="ar">
# نهاية الوردية — خط المواجهة

الترجمة قيد الإعداد لصفحة **End of Shift — Frontline**. يُرجى مراجعة النسخة الإنجليزية.

> [الاطلاع على الصفحة الإنجليزية]({{ "/end-of-shift-frontline" | relative_url }})
</div>
