---
layout: default
title: المكاتب / الإداري / قاعات التدريب
parent: إجراءات التشغيل — الصف الأول
nav_order: 5
---

<div dir="rtl" lang="ar">
# المكاتب / الإداري / قاعات التدريب

الترجمة قيد الإعداد لصفحة **Offices / Admin / Training Rooms**. يُرجى مراجعة النسخة الإنجليزية.

> [الاطلاع على الصفحة الإنجليزية]({{ "/offices-admin-training" | relative_url }})
</div>
