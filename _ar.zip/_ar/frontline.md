---
layout: default
title: إجراءات التشغيل — الصف الأول
parent: العربية
nav_order: 2
has_children: true
permalink: /ar/frontline/
slug: frontline
---

{% include lang_switch.html slug="frontline" %}

<div dir="rtl" lang="ar" markdown="1">
# إجراءات التشغيل — الصف الأول
</div>
