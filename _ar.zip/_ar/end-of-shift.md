---
layout: default
title: نهاية الوردية
parent: العربية
nav_order: 5
has_children: true
permalink: /ar/end-of-shift/
slug: end-of-shift
---

{% include lang_switch.html slug="end-of-shift" %}

<div dir="rtl" lang="ar" markdown="1">
# نهاية الوردية
</div>
