---
layout: default
title: Roles y Capacitación
parent: Español
nav_order: 4
has_children: true
permalink: /es/roles/
slug: roles
---

{% include lang_switch.html slug="roles" %}

# Roles y Capacitación
