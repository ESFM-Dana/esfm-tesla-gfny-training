---
layout: default
title: Fin de Turno — Personal Operativo
parent: Fin de Turno
nav_order: 1
---

# Fin de Turno — Personal Operativo

_Traducción pendiente de **End of Shift — Frontline**. Consulte la versión en inglés._

> [Ver la página en inglés]({{ "/end-of-shift-frontline" | relative_url }})
