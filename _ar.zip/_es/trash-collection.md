---
layout: default
title: Recolección de Basura (Interior y Exterior)
parent: Operaciones y Complementos
nav_order: 3
---

# Recolección de Basura (Interior y Exterior)

_Traducción pendiente de **Trash Collection (Interior & Exterior)**. Consulte la versión en inglés._

> [Ver la página en inglés]({{ "/trash-collection" | relative_url }})
