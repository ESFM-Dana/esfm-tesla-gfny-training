---
layout: default
title: Cómo Contribuir / Actualizar

nav_order: 7
slug: about
---

{% include lang_switch.html slug="about" %}

# Cómo Contribuir / Actualizar

Contenido pendiente.
