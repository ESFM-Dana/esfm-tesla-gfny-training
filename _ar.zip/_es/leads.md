---
layout: default
title: Líderes de Turno — Manual EVS
parent: Roles y Capacitación
nav_order: 2
slug: leads
---

{% include lang_switch.html slug="leads" %}

# Líderes de Turno — Manual EVS

Contenido pendiente.
