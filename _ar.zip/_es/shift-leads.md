---
layout: default
title: Líderes de Turno — Manual EVS
parent: Roles y Capacitación
nav_order: 2
---

# Líderes de Turno — Manual EVS

_Traducción pendiente de **Shift Leads — EVS Playbook**. Consulte la versión en inglés._

> [Ver la página en inglés]({{ "/shift-leads" | relative_url }})
