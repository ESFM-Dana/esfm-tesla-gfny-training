---
layout: default
title: Baños / Regaderas
parent: SOP de Operación — Frontline
nav_order: 1
slug: restrooms
---

{% include lang_switch.html slug="restrooms" %}

# Baños / Regaderas

Contenido pendiente.
