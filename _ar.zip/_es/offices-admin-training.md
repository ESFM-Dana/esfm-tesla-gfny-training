---
layout: default
title: Oficinas / Administrativo / Salas de Capacitación
parent: SOP de Operación — Frontline
nav_order: 5
---

# Oficinas / Administrativo / Salas de Capacitación

_Traducción pendiente de **Offices / Admin / Training Rooms**. Consulte la versión en inglés._

> [Ver la página en inglés]({{ "/offices-admin-training" | relative_url }})
