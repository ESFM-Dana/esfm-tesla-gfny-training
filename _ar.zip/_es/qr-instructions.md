---
layout: default
title: Instrucciones de QR — Solo al Salir
parent: Operaciones y Complementos
nav_order: 4
---

# Instrucciones de QR — Solo al Salir

_Traducción pendiente de **QR Instructions — Exit-Only Compliance**. Consulte la versión en inglés._

> [Ver la página en inglés]({{ "/qr-instructions" | relative_url }})
