---
layout: default
title: Gerentes — Manual EVS
parent: Roles y Capacitación
nav_order: 1
slug: managers
---

{% include lang_switch.html slug="managers" %}

# Gerentes — Manual EVS

Contenido pendiente.
