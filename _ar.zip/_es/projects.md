---
layout: default
title: Trabajo de Proyectos — Planeación y QA
parent: Roles y Capacitación
nav_order: 5
slug: projects
---

{% include lang_switch.html slug="projects" %}

# Trabajo de Proyectos — Planeación y QA

Contenido pendiente.
