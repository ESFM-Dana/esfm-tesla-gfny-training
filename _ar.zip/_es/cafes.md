---
layout: default
title: Cafés / Cocinetas / Áreas de descanso
parent: SOP de Operación — Frontline
nav_order: 2
slug: cafes
---

{% include lang_switch.html slug="cafes" %}

# Cafés / Cocinetas / Áreas de descanso

Contenido pendiente.
