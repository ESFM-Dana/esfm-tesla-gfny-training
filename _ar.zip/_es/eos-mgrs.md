---
layout: default
title: Fin de Turno — Gerentes
parent: Fin de Turno
nav_order: 2
slug: eos-mgrs
---

{% include lang_switch.html slug="eos-mgrs" %}

# Fin de Turno — Gerentes

Contenido pendiente.
