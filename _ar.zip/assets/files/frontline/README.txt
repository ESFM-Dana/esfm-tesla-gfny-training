Place downloadable files for Frontline here (PDFs, DOCX, etc.).
Example: frontline-quick-card.pdf
