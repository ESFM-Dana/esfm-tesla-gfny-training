Place downloadable files for Projects here (PDFs, DOCX, etc.).
Example: projects-quick-card.pdf
