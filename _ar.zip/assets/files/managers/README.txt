Place downloadable files for Managers here (PDFs, DOCX, etc.).
Example: managers-quick-card.pdf
