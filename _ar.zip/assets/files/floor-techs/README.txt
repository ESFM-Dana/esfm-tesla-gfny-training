Place downloadable files for Floor Techs here (PDFs, DOCX, etc.).
Example: floor-techs-quick-card.pdf
